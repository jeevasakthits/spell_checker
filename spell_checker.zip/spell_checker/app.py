from flask import Flask,render_template,request,url_for
import pandas as pd 
import numpy as np 
import re
from difflib import get_close_matches
import os

app = Flask(__name__)


@app.route('/')
def index():
	return render_template('index.html')


@app.route('/predict',methods=["GET","POST"])
def predict():
    os.chdir('F:/spell_checker')
    file=open("Hindi_Words.txt",encoding='utf8')
    words=[]
    for Line_in_File in file:
        s=re.sub("[\n]+","",Line_in_File)
        words.append(s)
    
    if request.method == 'POST':
        raw_text = request.form['rawtext']
        data = str(raw_text)
    word=data
    patterns = words
    val=[]
    for i in  word.split(' '):
        val.append(i)
        val.append(str((get_close_matches(i, patterns)))+'\n')
    return render_template('index.html',your_list=val,raw_text=raw_text)


if __name__ == '__main__':
	app.run(debug=True)

		
